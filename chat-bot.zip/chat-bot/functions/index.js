// // Create and Deploy Your First Cloud Functions //
// https://firebase.google.com/docs/functions/write-firebase-functions
//
// exports.helloWorld = functions.https.onRequest((request, response) => {
// response.send("Hello from Firebase!"); });

'use strict';
const request_lib = require('request');

const APIkey = "f619c4487dbb3c827a31c662be9b1044";

const DialogflowApp = require('actions-on-google').DialogflowApp;

// const ActionsSdkApp = require('actions-on-google').ActionsSdkApp;
const functions = require('firebase-functions');

const NO_INPUTS = ['I didn\'t hear that.', 'If you\'re still there, say that again.', 'We can stop here. See you soon.'];

exports.chatbot = functions
    .https
    .onRequest((request, response) => {
        const app = new DialogflowApp({request: request, response: response});
        // Create functions to handle requests here
        const WELCOME_INTENT = 'input.welcome';
        const Q1 = 'input.q1';
        const Q2 = 'input.q2';
        const Q3 = 'input.q3';

        function responseHandler(app) {

            // intent contains the name of the intent you defined in the Actions area of
            // Dialogflow
            let intent = app.getIntent();
            console.log("In response handler", intent);
            switch (intent) {
                case WELCOME_INTENT:
                    app.ask('how are you?');
                    break;
                case Q1:
                    // app.tell('did you just say ' + app.getRawInput() + '?');

                    app.ask('What kind of movie would you like to watch?');

                    break;
                case Q2:
                    app.tell('I\'m sorry that you are not feeling great');
                    break;
                case Q3:
                    let searchTerm = app.getRawInput();
                    const BaseURL = 'https://api.themoviedb.org/3/search/movie?api_key=' + APIkey + '&language=en-US&include_adult=false&sort_by=created_at.asc&query="' + searchTerm;
                    console.log(BaseURL);
                    request_lib(BaseURL, function (error, response, body) {
                        console.log('error:', error); // Print the error if one occurred
                        console.log('statusCode:', response && response.statusCode); // Print the response status code if a response was received
                        //   console.log('body:', body); // Print the HTML for the Google homepage.
                        // console.log( typeof body);
                        if (body) {
                            let parsedValue = JSON.parse(body);
                            // console.log( typeof parsedValue);
                            console.log(parsedValue.results[0].original_title);
                            app.tell('Here is a movie suggestion: ' + parsedValue.results[0].original_title);
                        } else {
                            app.tell('Nothing to display');
                        }
                    });
                    break;
                    // app.tell('I\'m glad you are in a happy mood');
                default:
                    app.tell(app.getIntent());
                    break;
            }
        }
        // you can add the function name instead of an action map
        app.handleRequest(responseHandler);
    });